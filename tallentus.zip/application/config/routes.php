<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/

$route['default_controller'] = "inicio/dashboard";

# Registro Usuario
$route['registro'] = "inicio/dashboard/registrar";
$route['entrar'] = "inicio/dashboard/entrar";
$route['salir'] = "inicio/dashboard/logout";
// $route['paso2'] = "inicio/dashboard/paso2";
$route['registro-paso-2/(:any)'] = "inicio/dashboard/paso2/$1";
$route['registro-paso-3'] = "inicio/dashboard/paso3";
$route['finalizar'] = "inicio/dashboard/paso3";

$route['mi-cuenta'] = "inicio/dashboard/perfil";


$route['admin'] = "login/inicio";

$route['404_override'] = '';


/* End of file routes.php */
/* Location: ./application/config/routes.php */