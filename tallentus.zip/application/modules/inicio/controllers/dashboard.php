<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
*************************************************************
Página/Clase    : Modules/Admin/Controller/login.php
Propósito       : Página de Administrador Dashboard
Notas           : N/A
Modificaciones  : N/A
******** Datos Creación *********
Autor           : Junior Tello
Fecha y hora    : 04/04/2015 - 15:12 hrs.
*************************************************************
*/
class Dashboard extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('inicio_model', 'inicio', TRUE);
    }

    public function index()
    {
        $web_css  = array(
            array('href'=>'assets/css/tallentus.min.css'),
            array('href'=>'assets/masterslider/style/masterslider.css'),
            array('href'=>'assets/masterslider/skins/default/style.css'),
        );
        $web_js   = array(  
            
        );  

        ## Inicio de Sesión
        $page_title = 'Tallentus - Inicio';
        ## Template Admin Dashboard
        $module     = 'inicio';
        $view       = 'index/index';

        $data = array(
            'titulo'     => $page_title,
            'web_css'    => $web_css,
            'web_js'     => $web_js,
            'module'     => $module,
            'view_file'  => $view
        );
        echo Modules::run('template/head_front',$data);
        echo Modules::run('template/front',$data);
    }


    public function paso2($email = null)
    {
        $web_css  = array(
            array('href'=>'assets/css/bootstrap.css'),
            array('href'=>'assets/css/theme.css'),
            array('href'=>'assets/css/waves.css'),
            array('href'=>'assets/masterslider/style/masterslider.css'),
            array('href'=>'assets/masterslider/skins/default/style.css'),
        );
        $web_js   = array(  
            
        );    
        ## Inicio de Sesión
        $page_title = 'Tallentus - Paso 2';
        ## Template Admin Dashboard
        $module     = 'inicio';
        $view       = 'index/paso_2';


        #Logica
        $vEmail = base64_decode($email);
        if(($vEmail == null or empty($vEmail)) and $this->session->userdata('email') == '' ){
            redirect('','refresh');
        }else{
            $arrEmail = $this->inicio->_obtener_email($vEmail);
            if(count($arrEmail)>0){
                $tEmail = $this->session->userdata('email');
            }else{
                $tEmail = '';
            }
        }

        $arrAreas = $this->inicio->_get_areas();

        #Vistas
        $data = array(
            'titulo'     => $page_title,
            'web_css'    => $web_css,
            'web_js'     => $web_js,
            'email'      => $tEmail,
            'areas'      => $arrAreas,
            'module'     => $module,
            'view_file'  => $view
        );
        echo Modules::run('template/head_front',$data);
        echo Modules::run('template/front',$data);
    }


    public function paso3()
    {
        $web_css  = array(
            array('href'=>'assets/css/bootstrap.css'),
            array('href'=>'script/materialize/css/materialize.css'),
            array('href'=>'assets/css/theme.css'),
            array('href'=>'assets/css/waves.css'),
            array('href'=>'assets/masterslider/style/masterslider.css'),
            array('href'=>'assets/masterslider/skins/default/style.css'),
        );
        $web_js   = array(  
            array('src'=>'script/materialize/js/materialize.js')
        );  
        ## Inicio de Sesión
        $page_title = 'Tallentus - Paso 3';
        ## Template Admin Dashboard
        $module     = 'inicio';
        $view       = 'index/paso_3';

        #Logica
        
        #### Obteniendo datos para mostrar
        $vEmail = $this->session->userdata('email');
        if($vEmail == null or empty($vEmail)){
            redirect('','refresh');
        }else{
            $arrEmail = $this->inicio->_obtener_email($vEmail);
            if(count($arrEmail)>0){
                $tEmail = $arrEmail;
            }else{
                redirect('','refresh');
            }
        }


        #### Metodos Post
            // var_dump($this->input->post()); die();
        if($this->input->post('nombre') != ''){
            $id                 = base64_decode($this->input->post('id'));
            $nombre             = $this->input->post('nombre');
            $apellido           = $this->input->post('apellido');
            $email              = $this->input->post('email');
            $dia                = $this->input->post('dia');
            $mes                = $this->input->post('mes');
            $anio               = $this->input->post('anio');
            $nrodocumento       = $this->input->post('nrodocumento');
            $sexo               = $this->input->post('sexo');
            $fijo               = $this->input->post('fijo');
            $celular            = $this->input->post('celular');
            $discapacidad       = $this->input->post('discapacidad');
            $texotdiscapacidad  = $this->input->post('texotdiscapacidad');
            
            $arrDatos = array(
                'usu_nombre'            => $nombre,
                'usu_apellidos'         => $apellido,
                // 'usu_correo'         => $email,
                // 'mes'                => $mes,
                // 'anio'               => $anio,
                'usu_fecha_creacion'    => $anio.'-'.$mes.'-'.$dia,
                'usu_nro_documento'     => $nrodocumento,
                'usu_sexo'              => $sexo,
                'usu_telefono'          => $fijo,
                'usu_celular'           => $celular,
                'usu_discapacidad'      => $discapacidad,
                'usu_texodiscapacidad'  => $texotdiscapacidad,
                'usu_fecha_modificacion'=> date('Y-m-d H:m:s')
            );
            
            // print_r($arrDatos);
            // print_r($id);
            $id = $this->inicio->_update('tbl_usuario',$arrDatos,$id);
            redirect('mi-cuenta','refresh');
        }
        
        #Vistas
        $data = array(
            'titulo'     => $page_title,
            'module'     => $module,
            'web_css'    => $web_css,
            'web_js'     => $web_js,
            'arrEmail'   => $tEmail,
            'view_file'  => $view
        );
        echo Modules::run('template/head_front',$data);
        echo Modules::run('template/front',$data);
    }
  

    public function registrar()
    {       
        
        $this->form_validation->set_rules('nombre', 'Nombre', 'required|xss_clean');
        $this->form_validation->set_rules('email', 'email', 'required|xss_clean');
        $this->form_validation->set_rules('password', 'password', 'required|xss_clean');
        $this->form_validation->set_rules('id', 'Código', 'xss_clean');
        if ($this->form_validation->run() == true)
        {
            $nombre     = $this->input->post('nombre');
            $email      = $this->input->post('email');
            $password   = $this->input->post('password');

            $arr_persona = array(
                'usu_nombre'        => $nombre,
                'usu_correo'        => $email,
                'usu_clave'         => sha1($password),
                'usu_estado'        => 1,
                'usu_tipo_doc'      => 1,
                'id_rol'            => 0,
                'usu_fecha_creacion'=> date('Y-m-d H:m:s')
            );
            
            $id = $this->inicio->_insertar('tbl_usuario',$arr_persona);
            $arrUsu = $this->inicio->_obtener_id((int)$id);
            $data = array(
                'is_logued_in'  =>  TRUE,
                'id_usuario'    =>  $arrUsu['usu_id'],
                'username'      =>  $arrUsu['usu_nombre'],
                'email'      =>  $arrUsu['usu_correo']
            );
            $this->session->set_userdata($data);
            $this->session->set_flashdata('message', 'inserto');
            redirect('registro-paso-2/'.base64_encode($email),'refresh');
        }else{
            $this->session->set_flashdata('message', 'error');
            print_r(validation_errors());
            die();
            redirect('','refresh');
        }

        ## Inicio de Sesión
        $data['page_title'] = 'Bolsa Trabajo';
    }

    public function entrar(){
        
        $this->form_validation->set_rules('email', 'Email', 'required|trim|min_length[2]|max_length[150]|xss_clean');
        $this->form_validation->set_rules('password', 'password', 'required|trim|min_length[6]|max_length[150]|xss_clean');
        //lanzamos mensajes de error si es que los hay
        $this->form_validation->set_message('required', 'El %s es requerido');
        $this->form_validation->set_message('min_length', 'El %s debe tener al menos %s carácteres');
        $this->form_validation->set_message('max_length', 'El %s debe tener al menos %s carácteres');
        if($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('usuario_incorrecto', 'error_login');
            print_r(validation_errors());
            redirect(base_url(),'refresh');
        }else{
            $username   = $this->input->post('email');
            $password   = sha1($this->input->post('password'));
            $check_user = $this->inicio->login_user($username,$password);
            if($check_user == TRUE)
            {
                $data = array(
                    'is_logued_in'  =>  TRUE,
                    'id_usuario'    =>  $check_user->usu_id,
                    'username'      =>  $check_user->usu_nombre,
                    'email'         =>  $check_user->usu_correo
                );
                
                $this->session->set_userdata($data);
                redirect(base_url(),'refresh');
            }else{
                $this->session->set_flashdata('usuario_incorrecto', 'error_login');
                redirect(base_url(),'refresh');
            }
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url(),'refresh');
    }



    public function perfil()
    {
        $web_css  = array(
            array('href'=>'assets/css/bootstrap.css'),
            array('href'=>'assets/materialize/css/materialize.css'),
            array('href'=>'https://fonts.googleapis.com/icon?family=Material+Icons'),
            array('href'=>'assets/css/theme.css'),
            array('href'=>'assets/css/waves.css'),
            array('href'=>'assets/masterslider/style/masterslider.css'),
            array('href'=>'assets/masterslider/skins/default/style.css'),
        );
        $web_js   = array(  
            
        );    
        ## Inicio de Sesión
        $page_title = 'Tallentus - Mi Perfil';
        ## Template Admin Dashboard
        $module     = 'inicio';
        $view       = 'index/perfil';


        #Logica
        $vEmail = $this->session->userdata('email');
        if($vEmail == null or empty($vEmail)){
            redirect('','refresh');
        }else{
            $arrEmail = $this->inicio->_obtener_email($vEmail);
            if(count($arrEmail)>0){
                $tEmail = $arrEmail;
            }else{
                redirect('','refresh');
            }
        }

        #Vistas
        $data = array(
            'titulo'     => $page_title,
            'web_css'    => $web_css,
            'datos'      => $tEmail,
            'web_js'     => $web_js,
            'module'     => $module,
            'view_file'  => $view
        );
        echo Modules::run('template/head_front',$data);
        echo Modules::run('template/front',$data);
    }





    public function nombreDep($id){
        $dep = $this->inicio->nomDep($id);
        return $dep['dep_var_descripcion']; 
    }

    public function nombreProv($id){
        $dep = $this->inicio->nomProv($id);
        return $dep['prv_var_descricpion']; 
    }

    public function nombreDist($id){
        $dep = $this->inicio->nomDist($id);
        return $dep['dist_var_descripcion']; 
    }


    public function cargaDepartamento()
    {
        echo $this->inicio->cargaDepartamento();
    }

    public function cargaProvincia($id = "")
    {
        echo $this->inicio->cargaProvincia($id);
    }

    public function cargaDistrito($id = "")
    {
        echo $this->inicio->cargaDistrito($id);
    }

    public function login_oportunidades(){
        ## Inicio de Sesión
        $data['page_title'] = 'Oportunidades Laborales';
        ## Template Admin Dashboard
        if($this->session->userdata('perfil') == FALSE || $this->session->userdata('perfil') != 'postulante')
        {
            $data['module'] = 'inicio';
            $data['view_file'] = 'oportunidades_lab_login_view';
            echo Modules::run('template/head_front',$data);
            echo Modules::run('template/front',$data);
            echo Modules::run('template/footer_front',$data);
        }else{
            $this->session->set_flashdata('mensaje','TU POSTULACIÓN HA SIDO REGISTRADA NOS COMUNICAREMOS EN LA BREVEDAD POSIBLE');
            redirect(base_url().'oportunidades-laborales','refresh');
        }
    }

    public function oportunidades_valid(){
        $id_user   = $this->input->post('valid');
        $convoca   = $this->input->post('cod_postula');
        
        if($id_user == '' || $convoca ==''){
            $this->session->set_flashdata('mensaje','Debe de iniciar sesión para portular');
            $this->session->set_flashdata('mensaje_confirm','error');
            redirect(base_url().'oportunidades-login','refresh');
        }else{
            $arr_convoca = array(
                'id_convoca' => $convoca,
                'id_postulante' => $id_user,
                'fecha' => date('Y-m-d H:m:s')
                );
            $this->inicio->inserta_convocatoria($arr_convoca);
            $this->session->set_flashdata('mensaje_confirm','insert');
            redirect(base_url().'oportunidades-login','refresh');

            // $this->session->set_flashdata('mensaje_confirm','TU POSTULACION HA SIDO ENVIADA MUCHAS GRACIAS');
        }
    }

}

/*
*end modules/login/controllers/dashboard.php
*/