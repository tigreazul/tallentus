<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
*************************************************************
Página/Clase    : Modules/Admin/Controller/login.php
Propósito       : Página de Administrador Dashboard
Notas           : N/A
Modificaciones  : N/A
******** Datos Creación *********
Autor           : Junior Tello
Fecha y hora    : 04/04/2015 - 15:12 hrs.
*************************************************************
*/
class Producto extends MX_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('inicio_model', 'inicio', TRUE);
    }

	public function index()
	{
		// $lst = $this->inicio->_lst_producto_cat((int)$id);
		// $rand = $this->inicio->_lst_producto_rand();
		// $categoria = $this->inicio->_lst_categoria();

		// $data = array(
		// 	'module' 	  => 'inicio',
		// 	'view_file'   => 'productos_view',
		// 	'lst_product' => $lst,
		// 	'lst_random'  => $rand,
		// 	'lst_categoria' => $categoria
		// );
		// ## Template Admin Dashboard
	 //    echo Modules::run('template/head_front',$data);
	 //    echo Modules::run('template/front',$data);	
	}

	public function men($id = false){

		$lst = $this->inicio->_lst_producto_cat(0,(int)$id);
		$rand = $this->inicio->_lst_producto_rand();
		$categoria = $this->inicio->_lst_categoria(0);

		$data = array(
			'module' 	    => 'inicio',
			'view_file'     => 'productos_view',
			'lst_product'   => $lst,
			'lst_random'    => $rand,
			'lst_categoria' => $categoria,
			'titulo_prod'	=> 'MEN',
			'imagen_cat'	=> 'bg-demo-2.jpg'
		);
		## Template Admin Dashboard
	    echo Modules::run('template/head_front',$data);
	    echo Modules::run('template/front',$data);	
	}

	public function women($id = false){
		
		$lst = $this->inicio->_lst_producto_cat(1,(int)$id);
		$rand = $this->inicio->_lst_producto_rand();
		$categoria = $this->inicio->_lst_categoria(1);

		$data = array(
			'module' 	    => 'inicio',
			'view_file'     => 'productos_view',
			'lst_product'   => $lst,
			'lst_random'    => $rand,
			'lst_categoria' => $categoria,
			'titulo_prod'	=> 'WOMEN',
			'imagen_cat'	=> 'bg-demo-2.jpg'
		);
		## Template Admin Dashboard
	    echo Modules::run('template/head_front',$data);
	    echo Modules::run('template/front',$data);	
	}

	public function detail($id)
    {
        
        if($id == ''){
            redirect(base_url().'inicio/dashboard','refresh');
        }else{
            $resultado_producto        = $this->inicio->_lst_producto_detail((int)$id);
            $data['prod_general_gale'] = $this->inicio->_lst_producto_galeria((int)$id);
            $data['prod_random']       = $this->inicio->_lst_producto_rand();
            $data['prod_general']      = $resultado_producto;
            $data['prod_opciones']     = $this->inicio->_lst_talla_producto($resultado_producto['prod_id']);
            
            ## Inicio de Sesión
            $data['page_title'] = 'Shop';

            ## Template Admin Dashboard
            $data['module'] = 'inicio';
            $data['view_file'] = 'detalle_producto_view';
            echo Modules::run('template/head_front',$data);
            echo Modules::run('template/front',$data);	
        }
    }

}

/* End of file men.php */
/* Location: ./application/modules/inicio/controllers/men.php */