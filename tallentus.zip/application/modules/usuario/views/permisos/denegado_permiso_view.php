<section id="content_wrapper">

    <!-- Start: Topbar -->
    <header id="topbar">
        <div class="topbar-left">
            <ol class="breadcrumb">
                <li class="crumb-active">
                    <a href="<?php echo base_url() ?>">Dashboard</a>
                </li>
                <li class="crumb-icon">
                    <a href="<?php echo base_url() ?>">
                        <span class="glyphicon glyphicon-home"></span>
                    </a>
                </li>
                <li class="crumb-trail">Permisos</li>
            </ol>
        </div>
    </header>
    <!-- End: Topbar -->

    <!-- Begin: Content -->
    <section id="content">
        <!-- begin: .tray-center -->
        <div class="tray tray-center p40 va-t posr">
            <div class="alert alert-default light alert-dismissable">
                No tienes permiso para realizar esta acción.
            </div>
        </div>
        <!-- end: .tray-center -->
    </section>
    <!-- End: Content -->

</section>