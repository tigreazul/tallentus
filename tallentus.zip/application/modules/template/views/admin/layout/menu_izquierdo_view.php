<aside id="sidebar_left" class="nano nano-primary">
    <div class="nano-content">

        <!-- sidebar menu -->
        <ul class="nav sidebar-menu">
            <li class="sidebar-label pt20">Menu</li>
            <li class="">
                <a class="accordion-toggle" href="#">
                    <span class="glyphicons glyphicons-cup"></span>
                    <span class="sidebar-title">Usuarios</span>
                    <span class="caret"></span>
                </a>
                <ul class="nav sub-nav">
                    <li>
                        <a href="<?php echo base_url().'usuario/dashboard' ?>">
                            <span class="glyphicons glyphicons-more_windows"></span> Usuarios 
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url().'usuario/rol' ?>">
                            <span class="glyphicons glyphicons-edit"></span> Roles 
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url().'usuario/permisos' ?>">
                            <span class="glyphicons glyphicons-calendar"></span> Permisos 
                        </a>
                    </li>
                </ul>
            </li>


        </ul>

    </div>
</aside>