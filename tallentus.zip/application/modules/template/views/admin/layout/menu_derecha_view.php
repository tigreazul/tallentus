<!-- <div class="col w-md bg-white-only b-l bg-auto no-border-xs">  
  <div class="padder-md">
    <div class="m-b text-md" style="margin-top: 15px;">Actividades Recientes</div>  
    <div class="streamline b-l m-b">
      <div class="sl-item b-success b-l">
        <div class="m-l">
          <div class="text-muted">10:30</div>
          <p>Call to customer <a href class="text-info">Jacob</a> and discuss the detail.</p>
        </div>
      </div>
    </div>
    <p>No hay actividades</p>
  </div>
</div> -->